// Selection des élément
const clientForm = 
document.getElementById("clientForm");
const clientList = 
document.getElementById("clientList");

//chargement des clients 
let clients =
JSON.parse(localStorage.getItem
    ("clients")) || [];

    //fonction d'affichage des clients
    function afficherClients() {
        clientList.innerHTML = "";
        clients.forEach((client,index) =>{
            const card = 
            document.createElement("div");
            card.className = 
            "client-card";
            const nom =
            document.createElement("p");
            nom.textContent = 
            + client.nom;

            const email =
            document.createElement("p");
            email.textContent = 
            + client.email;


            const telephone =
            document.createElement("p");
            telephone.textContent = 
            + client.telephone;

            // button de suppression
            const btnSupprimer = 
            document.createElement("button");
            btnSupprimer.textContent =
            "Supprimer";

            btnSupprimer.addEventListener ("click" ,() => {
                clients.splice(index, 1);

                localStorage.setItem("clients" ,
                JSON.stringify(clients));
                afficherClients();
            });

            //afficher des elements dans la carte 
            card.appendChild(nom);
            card.appendChild(email);
            card.appendChild(telephone);
            card.appendChild(btnSupprimer);

            //ajout de la carte au conteneur
            clientList.appendChild(card);
         });
        }

        //Gestion du formulaire d'ajout
        clientForm.addEventListener("submit" , (e) => {
            e.preventDefault();

            const nom =
            document.getElementById("nom").value;

            const email =
            document.getElementById("email").value;

            const telephone =
            document.getElementById("telephone").value;

            const nouveauClient = 
            {nom, email, telephone};
            clients.push(nouveauClient);

            localStorage.setItem("clients" ,
            JSON.stringify(clients));
            afficherClients();

            clientForm.reset();
        });

        afficherClients();

        
// Recherche en temps réél des clients
const searchClient = 
document.getElementById("searchClient");
searchClient.addEventListener("input", () => {
    const searchTerm = 
    searchClient.value.toLowerCase ();

    // filtrer les biens 
    const filtrerdClient =
    clients.filter(client => 
       client.nom.toLowerCase().include 
        (searchTerm) ||

        client.email.toLowerCase().include 
        (searchTerm) 
        );
        //reafficher seulements les biens filter
        afficherClients(filtrerdClient);

});
// modif de la fonction afficherBiens
function afficherClients(liste = clients) {
    clientCards.innerHTML ="";

    liste.forEach((client , index) => {
        const card = 
        document.createElement("div");

        card.className = 
        "client-card";

        const nom = 
        document.createElement("p");
        nom.textContent = +client.nom;

        const email = 
        document.createElement("p");
        email.textContent = +client.email;

        const btn = 
        document.createElement("button");
        btn.textContent = "Supprimer";

        btn.addEventListener("click",() => {
            clients.splice(index,1);

            localStorage.setItem("clients",
            JSON.stringify(clients) );
            afficherClients();
        });

        card.appendChild(nom);
        card.appendChild(email);
        card.appendChild(btn);

        clientCards.appendChild(card);
    });
}