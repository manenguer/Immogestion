document.addEventListener("DOMContentLoaded" ,() => {
const logoutBtn = document.querySelector(".logout");
if (logoutBtn) {
    logoutBtn.addEventListener(
        "click" , (e) => {
            e.preventDefault();
            const confirmLogout = 
            confirm("Voulez-vous vraiment vous déconnecter ?");
            if (confirmLogout) {
                window.location.href
                = "form.html" ;
            }
        }
    );
}
}
);