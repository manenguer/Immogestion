// Selection des élément
const transactionForm = 
document.getElementById("transactionForm");
const clientList = 
document.getElementById("transactions");

//chargement des transactions
let  transactions =
JSON.parse(localStorage.getItem
    (" transactions")) || [];

    //fonction d'affichage des  transactions
    function afficherTransactions() {
        transactionsDiv.innerHTML = "";
        transactions.forEach((trans,index) => {
            const card = 
            document.createElement("div");
            card.className = 
            " transaction-card";

            const client =
            document.createElement("p");
            client.textContent = 
             "Client :" + trans.client;

            const bien =
            document.createElement("p");
            bien.textContent = 
            "Bien :"  + trans.bien;


            const montant =
            document.createElement("p");
            montant.textContent = 
            "Montant :"  + trans.montant + "FCFA";

            const type =
            document.createElement("p");
            type.textContent = 
            "Type:"  + trans.type;

            // button de suppression
            const btnSupprimer = 
            document.createElement("button");
            btnSupprimer.textContent =
            "Supprimer";

            btnSupprimer.addEventListener ("click" ,() => {
                transactions.splice(index, 1);

                localStorage.setItem("transactions" ,
                JSON.stringify(transactions));
                afficherTransactions();
            });

            //afficher des elements dans la carte 
            card.appendChild(client);
            card.appendChild(bien);
            card.appendChild(montant);
            card.appendChild(type);
            card.appendChild(btnSupprimer);

            transactionsDiv.appendChild(card);
         });
        }

        //Gestion du formulaire d'ajout
        transactionForm.addEventListener("submit" , (e) => {
            e.preventDefault();

            const client =
            document.getElementById("client").value;

            const bien =
            document.getElementById("bien").value;

            const montant =
            document.getElementById("montant").value;

            const type =
            document.getElementById("type").value;

            const nouvelleTransaction = 
            {client, bien, montant, type};
            transaction.push(nouvelleTransaction);

            localStorage.setItem("transactions" ,
            JSON.stringify(transaction));
            afficherTransactions();

            transactionForm.reset();
        });

        afficherTransactions();