<?php
include 'config/database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $motdepasse = $_POST["motdepasse"];

    $sql = "SELECT * FROM utilisateurs WHERE email = ? AND motdepasse = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email, $motdepasse]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(["success" => true, "message" => "Connexion réussie"]);
    } else {
        echo json_encode(["success" => false, "message" => "Identifiants incorrects"]);
    }
}
?> 