//Selection des element
const form = 
document.getElementById("propertyform");
const propertyCard = 
document.getElementById ("propertyCard");
//stocker les biens 
let biens = 
JSON.parse(localStorage.getItem("biens")) || [];
//afficher un bien 
function afficherbiens() {
    propertyCard.innerHTML = "";
    biens.forEach((bien,index) => {
        const card = 
        document.createElement("div");
        card.className = 
        "property-card";
        //on affiche l'image s'il existe
        if (bien.image) {
            const img = 
            document.createElement("img");
            img.src = bien.image;
            img.alt = "Image du bien";
            card.appendChild(img)
        }
        //ajout du titre et du prix 
        const titre = 
        document.createElement ("p");
        titre.textContent = +bien.titre;

        const prix = 
        document.createElement ("p");
        prix.textContent = +bien.prix;

        const localisation = 
        document.createElement ("p");
        localisation.textContent = +bien.localisation;

        // Bouton de suppression 
        const btn = 
        document.createElement("button");
        btn.textContent = "supprimer";

        btn.addEventListener("click" , () => {
            biens.splice(index,1);

            localStorage.setItem("biens" ,JSON.stringify(biens));
            afficherBiens();
        } )
        // ajout des elements
        card.appendChild(titre);
        card.appendChild(prix);
        card.appendChild(localisation);
        card.appendChild(btn);

        propertyCard.appendChild(card);

    } );
}
// form:ajout d'un nouveau bien
form.addEventListener("submit" ,(e) => {
e.preventDefault();
const titre =
document.getElementById("titre").value ;

const localisation =
document.getElementById("localisation").value ;

const prix =
document.getElementById("prix").value ;

const imageFile =
document.getElementById("image").files[0] ;
// lecture de l'image 
if (imageFile) {
    const reader = new 
    FileReader();
    reader.onload = function (){
        const imageData = 
        reader.result;
        ajouterBien(titre,localisation,prix,imageData);
    };
    reader.readAsDataURL(imageFile)
}
 else {
    ajouterBien(titre,localisation,prix,null);
 }
 // reinitialiser le form 
 form.reset();
});
// ajouter un bien au tableau 
function ajouterBien(titre,localisation,prix,image){
    const nouveauBien = {
        titre,
        localisation,
        prix,
        image
    };
    bien.push(nouveauBien);
    localStorage.setItem("biens" ,
    JSON.stringify(biens));
    afficherbiens();
}
// initialisation a l'ouverture 
afficherBiens();

// Recherche en temps réél des biens
const searchBien = 
document.getElementById("searchBien");
searchBien.addEventListener("input", () => {
    const searchTerm = 
    searchBien.value.toLowerCase ();

    // filtrer les biens 
    const filtrerdBiens  =
    biens.filter(bien => 
       bien.titre.toLowerCase().include 
        (searchTerm) ||

        bien.localisation.toLowerCase().include 
        (searchTerm) 
        );
        //reafficher seulements les biens filter
        afficherBiens(filtrerdBiens);

});
// modif de la fonction afficherBiens
function afficherBiens(liste = biens) {
    propertyCards.innerHTML ="";

    liste.forEach((bien , index) => {
        const card = 
        document.createElement("div");

        card.className = 
        "property-card";

        if (bien.image) {
            const img = 
            document.createElement("img");

            img.src = bien.image;
            img.alt = "Image du bien";

            card.appendChild(img);
        }

        const titre = 
        document.createElement("p");
        titre.textContent = +bien.titre;

        const prix = 
        document.createElement("p");
        prix.textContent = +bien.prix +"FCFA";

        const localisation = 
        document.createElement("p");
        localisation.textContent = +bien.localisation;

        const btn = 
        document.createElement("button");
        btn.textContent = "Supprimer";

        btn.addEventListener("click",() => {
            biens.splice(index,1);

            localStorage.setItem("biens",
            JSON.stringify(biens) );
            afficherBiens();
        });

        card.appendChild(titre);
        card.appendChild(prix);
        card.appendChild(localisation);
        card.appendChild(btn);

        propertyCards.appendChild(card);
    });
}