//basculez entre les onglets
const logintab =
document.getElementById ("login-tab") ;
const registertab =
document.getElementById ("register-tab") ;

const loginform = 
document.getElementById("login-form");
const registerform = 
document.getElementById("register-form");

logintab.onclick = ()=>{
    logintab.classList.add("active");
    registertab.classList.remove("active");
    loginform.classList.add("active");
    registerform.classList.remove("active");
};
registertab.onclick = () =>{
    registertab.classList.add("active");
    logintab.classList.remove("active")
    registerform.classList.add("active");
    loginform.classList.remove("active")
};

//Ecouteur formulaire de connexion

loginform.addEventListener 
("submit" ,(e) =>{
    e.preventDefault();
    //recuperation des valeurs 
    const username =
    document.getElementById("login-username").value;
    const password = 
    document.getElementById("login-password").value;
    //envoi des donnee au serveur
    fetch("login.php",
        {
            method:"POST" ,
            headers: {
                "content-type":"application/json",
            },
            body:
            JSON.stringify({username,password}),
        })
.then((reponse) =>
    reponse.json())
//convertir en json
.then ((data) => {
    console.log(data);
    if(data.success) {
        window.location.href = 
        "dashboard.html" ;
    } else {
        alert("Email ou mot de passe incorrect");
    }
})
.catch((error) => {
    console.error("Erreur :",error );
});
});

//Ecouteur formulaire d'inscription
registerform.addEventListener 
("submit" ,(e) =>{
    e.preventDefault();
    //recuperation des valeurs 
    const username =
    document.getElementById("register-username").value;
 const email =
    document.getElementById("register-email").value;
    const password = 
    document.getElementById("register-password").value;
    //envoi des donnee au serveur
    fetch("register.php",
        {
            method:"POST" ,
            headers: {
                "content-type":"application/json",
            },
            body:
            JSON.stringify({username,email,password}),
        })
.then((reponse) =>
    reponse.json())
//convertir en json
.then ((data) => {
    console.log(data);
})
.catch((error) => {
    console.error("Erreur :",error );

});
});
if (window.location.pathname.includes
    ("form.html")) {
        loginform.addEventListener("submit" , (e) => {
            e.preventDefault();

        
        } );

    }
